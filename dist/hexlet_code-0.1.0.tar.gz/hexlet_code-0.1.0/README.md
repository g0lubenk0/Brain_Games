### Hexlet tests and linter status:
[![Actions Status](https://github.com/g0lubenk0/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/g0lubenk0/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/026fefad4d59a2bdbc31/maintainability)](https://codeclimate.com/github/g0lubenk0/python-project-49/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/026fefad4d59a2bdbc31/test_coverage)](https://codeclimate.com/github/g0lubenk0/python-project-49/test_coverage)

[![asciicast](https://asciinema.org/a/K0xP7aqPAfRjKbvuDtQGWovv3.svg)](https://asciinema.org/a/K0xP7aqPAfRjKbvuDtQGWovv3)
